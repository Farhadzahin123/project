package collection_java;
import java.util.Stack;

public class Stacks {

	public static void main(String[] args) {
	Stack<String> st = new Stack<String>();
	st.push("farhad");
	st.push("farid");
	st.push("sadiq");
	st.push("sharif");
	st.push("zahin");
	System.out.println(st);
	st.peek();
	System.out.println(st);
	st.pop();
	System.out.println(""+st);
	
	

	}

}
