package pac_1;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> mhash = new HashSet<String>();
		mhash.add("farhad");
		mhash.add("kochai");
		mhash.add("farid");
		mhash.add("sadiq");
		mhash.add("shrif");
		
		System.out.println("my hash set=="+mhash);
		//both not support duplicute value
//		linked hash set is order data showing
		LinkedHashSet<String> mhash2 = new LinkedHashSet<String>();
		mhash2.add("farhad");
		mhash2.add("kochai");
		mhash2.add("farid");
		mhash2.add("sadiq");
		mhash2.add("shrif");
		System.out.println("my hash set2=="+mhash2);
		
		
		

	}

}
