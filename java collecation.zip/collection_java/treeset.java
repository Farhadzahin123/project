package collection_java;

import java.util.TreeSet;

public class treeset {

	public static void main(String[] args) {
	
		TreeSet<String> sl =new TreeSet<String>();
		sl.add("zhain");
		sl.add("stooman");
		sl.add("saeed");
		sl.add("zahid");
		sl.add("kochai");
		
		System.out.println(sl.toString());
		TreeSet<Integer> tl =new TreeSet<Integer>();
		tl.add(12);
		tl.add(33);
		tl.add(23);
		tl.add(5);
		tl.add(23);
		tl.add(55);
		System.out.println(tl);
		
		
		

	}

}
