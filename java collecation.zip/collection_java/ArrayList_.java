package collection_java;
import java.util.ArrayList;
import java.util.Iterator;

public class ArrayList_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ArrayList<String> alist = new ArrayList<String>();
	
	
	alist.add("farhad");
	alist.add("farid");
	alist.add("kochai");
	alist.add("sharif");
	alist.add("sadiq");
	alist.add("zahin");
	Iterator<String> mIterator = alist.iterator();
	while(mIterator.hasNext());
	
	String s = (String)mIterator.next();
	
	System.out.print(s);
	

	}

}
