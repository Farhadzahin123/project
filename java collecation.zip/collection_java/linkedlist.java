package collection_java;

import java.util.LinkedList;

public class linkedlist {

	public static void main(String[] args) {
		LinkedList<String> mlist = new LinkedList<String>();
		mlist.add("fahrad");
		mlist.add("farid");
		mlist.add("kochai");
		mlist.add("zhain");
		mlist.add("stooman");
		mlist.add("Hlimai");
		
		System.out.println(mlist);
		mlist.addFirst("sadiq");
		mlist.addLast("sharif");
		System.out.println(mlist);
		mlist.add(2, "zahid");
		System.out.println(mlist);
		mlist.remove();
		System.out.println("remove the first elements==>:-"+mlist.remove());
		mlist.remove(3); // specific element
   System.out.println("specific elements=>:"+mlist.remove());
              mlist.removeLast();
              System.out.println("remove the last element=>:"+mlist.removeLast());
	}

}
