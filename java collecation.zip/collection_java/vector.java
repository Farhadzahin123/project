package pac_1;
import java.util.Vector;
import f

public class test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector mvector =new Vector()
				mvector.add("fahrad");
		    mvector.add("khan");
		    mvector.add("ali");
		    mvector.add("zahin");
		    //
		    
		    System.out.println(mvector);

	}

}
