package collection_java;

import java.util.Deque;
import java.util.ArrayDeque;

public class Dque {

	public static void main(String[] args) {
		Deque<String> dq = new ArrayDeque<String>();
		dq.add("farhad");
		dq.add("zahin");
		dq.add("farid");
		dq.add("sharif");
		dq.add("sadeeq");
		
		for(String str:dq) {
			System.out.println(str);
		}
		

	}

}
