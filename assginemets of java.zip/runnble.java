package myclass;

public class runnble implements Runnable {
	public void run() {
		System.out.print("hi dear freind");
	}
  public static void main(String[] args) {
	  Thread T =new Thread(new runnble());
	  T.start();
  }
}
