package package_collection;

public class zahin {
	private final String user;
	zahin(String user){
		this.user=user;
		
	}
	public final String getname() {
		return user;
	}
 public static void  main(String[] args) {
	 zahin z =new zahin("farid");
	 System.out.print(z.getname());
   
 }
}
