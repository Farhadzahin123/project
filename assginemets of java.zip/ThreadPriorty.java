package myclass;

public class ThreadPriorty extends Thread {
	public void run() {
		System.out.print("running thread priorty ");
		thread.currentThread().getPriority();
	}
	

	public static void main(String[] args) {
		ThreadPriorty t= new ThreadPriorty();
		ThreadPriorty t2= new ThreadPriorty();
		t.setPriority(MAX_PRIORITY);
		t2.setPriority(MIN_PRIORITY);
		t.start();
		t2.start();
		

	}

}
