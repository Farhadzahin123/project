package thread;

public class mythread extends Thread{
	public void run() {
		System.out.print("thread");
	}
public static void main(String[] args) {
	mythread T = new mythread();
	T.start();
}
}
